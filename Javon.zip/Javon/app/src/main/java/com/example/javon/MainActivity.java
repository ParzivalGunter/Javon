package com.example.javon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BaseDatos();

        Button BtnAgregarLinks = (Button) findViewById(R.id.btnAgregarLink);
        Button BtnListado = (Button) findViewById(R.id.btnListado);
        TextView txtRegistro = (TextView) findViewById(R.id.txtRegistro);
        TextView txtBuscar = (TextView) findViewById(R.id.txtBuscar);
        Button btnRedes = (Button) findViewById(R.id.btnRedes);
        Button btnBorrador = (Button) findViewById(R.id.btnBorrador);
        Button btnActualizado = (Button) findViewById(R.id.btnActualizado);

        BtnAgregarLinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent agregar = new Intent(MainActivity.this, AgregarLink.class);
                startActivity(agregar);
            }


        });

        BtnListado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cadena = txtBuscar.getText().toString();
                Intent presentacion = new Intent(MainActivity.this, listadoLinks.class);
                presentacion.putExtra("cadena", cadena);
                startActivity(presentacion);

            }
        });

        btnRedes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent redes = new Intent(MainActivity.this, Redes.class);
                startActivity(redes);
            }

        });

        btnBorrador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent borrar = new Intent(MainActivity.this, BorrarLink.class);
                startActivity(borrar);
            }
        });

        btnActualizado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent actualizado = new Intent(MainActivity.this, Actualizar.class);
                startActivity(actualizado);
            }
        });

    }





    protected void BaseDatos(){
        SQLiteDatabase bd = openOrCreateDatabase("Javon_app", MODE_PRIVATE, null);
        bd.execSQL("create table if not exists links(_id integer primary key autoincrement, nombre TEXT NOT NULL, url TEXT NOT NULL)");
        bd.execSQL("create table if not exists usuarios(_id integer primary key autoincrement, nombre TEXT NOT NULL, correo TEXT NOT NULL)");
    }

    @Override
    public void onResume(){
        super.onResume();
        //Toast.makeText(MainActivity.this, "Ejecutando", Toast.LENGTH_LONG).show();
        SQLiteDatabase bd = openOrCreateDatabase("Javon_app",MODE_PRIVATE,null);
        Cursor contador = bd.rawQuery("select count(*) from links", null);
        contador.moveToFirst();
        TextView txtCantidad = (TextView) findViewById(R.id.txtRegistro);
        int cantidad = contador.getInt(0);
        txtCantidad.setText(cantidad + " registros");
        contador.close();
}

    }