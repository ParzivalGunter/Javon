package com.example.javon;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.net.URI;

public class listadoLinks extends AppCompatActivity {

    @SuppressLint({"Range", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listado);

        String value = getIntent().getExtras().getString("cadena");
        String nombre;
        int id;
        LinearLayout layout = (LinearLayout) findViewById(R.id.resultado);

        SQLiteDatabase bd = openOrCreateDatabase("Javon_app", MODE_PRIVATE,null);
        Cursor contador = bd.rawQuery("select _id, nombre, url from links where nombre LIKE '%" + value + "%'", null);
        if (contador != null){
            if (contador.moveToFirst()){
                do {
                    id = contador.getColumnIndex("_id");
                    nombre = contador.getString(contador.getColumnIndex("nombre"));
                    final String url = contador.getString(contador.getColumnIndex("url"));
                    Button btnLink = new Button(this);
                    btnLink.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    btnLink.setText(nombre + " (" + url + ")");
                    btnLink.setId(id);
                    layout.addView(btnLink);

                    btnLink.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Uri link = Uri.parse(url);
                            Intent i = new Intent(Intent.ACTION_VIEW,link);
                            startActivity(i);
                        }
                    });

                } while (contador.moveToNext());
            }
        }
        contador.close();
}

}
