package com.example.javon;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Redes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.redes);

        Button youtube = (Button) findViewById(R.id.btn_youtube);
        Button discord = (Button) findViewById(R.id.btn_discord);
        Button facbook = (Button) findViewById(R.id.btn_facebook);


        youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri link = Uri.parse("https://www.youtube.com/channel/UCv0Deq-htpHR4qqoyNq_DgQ");
                Intent i = new Intent(Intent.ACTION_VIEW, link);
                startActivity(i);

            }
        });

        discord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri link = Uri.parse("https://discord.com");
                Intent i = new Intent(Intent.ACTION_VIEW, link);
                startActivity(i);

            }
        });

        facbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri link = Uri.parse("https://facebook.com");
                Intent i = new Intent(Intent.ACTION_VIEW, link);
                startActivity(i);

            }
        });

    }
}
