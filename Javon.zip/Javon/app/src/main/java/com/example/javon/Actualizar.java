package com.example.javon;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Actualizar extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actualizar);

        TextView txtRegistroaEditar = (TextView) findViewById(R.id.txtRegistroaEditar);
        TextView txtNombreaCambiar = (TextView) findViewById(R.id.txtNombreaCambiar);
        TextView txtUrlaCambiar = (TextView) findViewById(R.id.txtUrlaCambiar);
        Button btnActualizar = (Button) findViewById(R.id.btnActualizar);

        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Registro = txtRegistroaEditar.getText().toString();
                String Nombre = txtNombreaCambiar.getText().toString();
                String URL = txtUrlaCambiar.getText().toString();
                SQLiteDatabase bd = openOrCreateDatabase("Javon_app", MODE_PRIVATE, null);
                Cursor cont = bd.rawQuery("select count(*) from links WHERE nombre LIKE '%" + Registro + "%'", null);
                cont.moveToFirst();
                if (txtRegistroaEditar.getText() == "" && txtNombreaCambiar.getText() == "" && txtUrlaCambiar.getText() == "") {
                    Toast.makeText(Actualizar.this, "No se ha seleccionado ningún registro a cambiar", Toast.LENGTH_LONG).show();
                } else if (cont.getInt(0) > 1) {
                    Toast.makeText(Actualizar.this, "Ingrese un criterio más específico", Toast.LENGTH_LONG).show();
                } else {
                    bd.execSQL("UPDATE links SET nombre = '"+ Nombre +"', url = '"+ URL +"' WHERE nombre LIKE '%"+ Registro +"%'");
                    Toast.makeText(Actualizar.this, "Registro actualizado con exito", Toast.LENGTH_LONG).show();
                    txtRegistroaEditar.setText("");
                    txtNombreaCambiar.setText("");
                    txtUrlaCambiar.setText("");
                }
            }
        });

    }
}
