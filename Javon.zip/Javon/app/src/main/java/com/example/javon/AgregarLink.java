package com.example.javon;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AgregarLink  extends AppCompatActivity {


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.agregar_link);


            TextView txtNombre = (TextView) findViewById(R.id.txtNombre);
            TextView txtUrl = (TextView) findViewById(R.id.txtUrl);
            Button btnAgregar = (Button) findViewById(R.id.btnRegistrar);

            btnAgregar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String nombre = txtNombre.getText().toString();
                    String url = txtUrl.getText().toString();
                    SQLiteDatabase bd = openOrCreateDatabase("Javon_app", MODE_PRIVATE, null);
                    bd.execSQL("insert into links(nombre, url) values('" +nombre+ "', '" +url+ "')");
                    Toast.makeText(AgregarLink.this, "Link Agregado", Toast.LENGTH_LONG).show();
                    txtNombre.setText("");
                    txtUrl.setText("");
                }
            });


        }

    }




