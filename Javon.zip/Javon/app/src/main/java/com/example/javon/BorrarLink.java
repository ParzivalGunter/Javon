package com.example.javon;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BorrarLink extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.borrar_link);


        TextView txtBorrar = (TextView) findViewById(R.id.txtBorrado);
        Button btnBorrar = (Button) findViewById(R.id.btnBorrar);
        Button btnTotal = (Button) findViewById(R.id.btnTotal);


        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String borrar = txtBorrar.getText().toString();
                SQLiteDatabase bd = openOrCreateDatabase("Javon_app", MODE_PRIVATE, null);
                Cursor cont = bd.rawQuery("select count(*) from links WHERE nombre LIKE '%" + borrar + "%'", null);
                cont.moveToFirst();
                if (txtBorrar.getText() == "") {
                    Toast.makeText(BorrarLink.this, "No se especifica ningún registro a borrar", Toast.LENGTH_LONG).show();
                } else if (cont.getInt(0) > 1){
                        Toast.makeText(BorrarLink.this, "Ingrese un criterio más especifico.", Toast.LENGTH_LONG).show();
                    } else {
                    bd.execSQL("delete from links where nombre like '%" + borrar + "%'");
                    Toast.makeText(BorrarLink.this, "Registro eliminado con exito", Toast.LENGTH_LONG).show();
                    txtBorrar.setText("");
                }

            }
        });

        btnTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase bd = openOrCreateDatabase("Javon_app", MODE_PRIVATE, null);
                bd.execSQL("DELETE FROM links");
                Toast.makeText(BorrarLink.this, "Todos los registros han sido borrados", Toast.LENGTH_LONG).show();
            }
        });

    }
    }